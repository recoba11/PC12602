package pe.edu.upc.equipo1.tp2entities;

import jakarta.persistence.*;

@Entity
@Table(name = "training_category")
public class tp2TrainingCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tp2_id_category")
    private int tp2IdCategory;

    @Column(name = "tp2_name", length = 150, nullable = false)
    private String tp2Name;

    @Column(name = "tp2_description", columnDefinition = "TEXT")
    private String tp2Description;

    public tp2TrainingCategory() {
    }

    public tp2TrainingCategory(int tp2IdCategory, String tp2Name, String tp2Description) {
        this.tp2IdCategory = tp2IdCategory;
        this.tp2Name = tp2Name;
        this.tp2Description = tp2Description;
    }

    public int getTp2IdCategory() {
        return tp2IdCategory;
    }

    public void setTp2IdCategory(int tp2IdCategory) {
        this.tp2IdCategory = tp2IdCategory;
    }

    public String getTp2Name() {
        return tp2Name;
    }

    public void setTp2Name(String tp2Name) {
        this.tp2Name = tp2Name;
    }

    public String getTp2Description() {
        return tp2Description;
    }

    public void setTp2Description(String tp2Description) {
        this.tp2Description = tp2Description;
    }
}
