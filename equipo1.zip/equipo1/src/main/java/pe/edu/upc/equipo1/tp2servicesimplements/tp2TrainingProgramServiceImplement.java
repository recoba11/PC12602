package pe.edu.upc.equipo1.tp2servicesimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.equipo1.tp2dtos.tp2TrainingQuantityDTO;
import pe.edu.upc.equipo1.tp2entities.tp2TrainingProgram;
import pe.edu.upc.equipo1.tp2repositories.Itp2TrainingActivityRepository;
import pe.edu.upc.equipo1.tp2repositories.Itp2TrainingProgramRepository;
import pe.edu.upc.equipo1.tp2servicesinterfaces.Itp2TrainingProgramService;

import java.util.List;
import java.util.Optional;

@Service
public class tp2TrainingProgramServiceImplement implements Itp2TrainingProgramService {

    @Autowired
    private Itp2TrainingProgramRepository e2_programRepository;

    @Autowired
    private Itp2TrainingActivityRepository e2_activityRepository;

    @Override
    public Optional<tp2TrainingProgram> listId(int id) {
        return e2_programRepository.findById(id);
    }

    @Override
    public tp2TrainingProgram update(int id, tp2TrainingProgram program) {
        Optional<tp2TrainingProgram> e2_existente = e2_programRepository.findById(id);

        if (e2_existente.isEmpty()) {
            return null;
        }

        tp2TrainingProgram e2_programaActualizado = e2_existente.get();
        e2_programaActualizado.setTp2Denomination(program.getTp2Denomination());
        e2_programaActualizado.setTp2Description(program.getTp2Description());
        e2_programaActualizado.setTp2Modality(program.getTp2Modality());
        e2_programaActualizado.setTp2DateProgram(program.getTp2DateProgram());

        return e2_programRepository.save(e2_programaActualizado);
    }

    @Override
    public List<tp2TrainingQuantityDTO> quantitiesByProgramAndCategory() {
        return e2_activityRepository.tp2_findQuantitiesByProgramAndCategory();
    }
}
