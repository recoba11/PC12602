package pe.edu.upc.equipo1.tp2entities;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "training_program")
public class tp2TrainingProgram {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tp2_id_program")
    private int tp2IdProgram;

    @Column(name = "tp2_denomination", length = 200, nullable = false)
    private String tp2Denomination;

    @Column(name = "tp2_description", columnDefinition = "TEXT")
    private String tp2Description;

    @Column(name = "tp2_modality", length = 20, nullable = false)
    private String tp2Modality;

    @Column(name = "tp2_date_program", nullable = false)
    private LocalDate tp2DateProgram;

    public tp2TrainingProgram() {
    }

    public tp2TrainingProgram(int tp2IdProgram, String tp2Denomination, String tp2Description,
                               String tp2Modality, LocalDate tp2DateProgram) {
        this.tp2IdProgram = tp2IdProgram;
        this.tp2Denomination = tp2Denomination;
        this.tp2Description = tp2Description;
        this.tp2Modality = tp2Modality;
        this.tp2DateProgram = tp2DateProgram;
    }

    public int getTp2IdProgram() {
        return tp2IdProgram;
    }

    public void setTp2IdProgram(int tp2IdProgram) {
        this.tp2IdProgram = tp2IdProgram;
    }

    public String getTp2Denomination() {
        return tp2Denomination;
    }

    public void setTp2Denomination(String tp2Denomination) {
        this.tp2Denomination = tp2Denomination;
    }

    public String getTp2Description() {
        return tp2Description;
    }

    public void setTp2Description(String tp2Description) {
        this.tp2Description = tp2Description;
    }

    public String getTp2Modality() {
        return tp2Modality;
    }

    public void setTp2Modality(String tp2Modality) {
        this.tp2Modality = tp2Modality;
    }

    public LocalDate getTp2DateProgram() {
        return tp2DateProgram;
    }

    public void setTp2DateProgram(LocalDate tp2DateProgram) {
        this.tp2DateProgram = tp2DateProgram;
    }
}
