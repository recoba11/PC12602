package pe.edu.upc.equipo1.tp2entities;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "training_activity")
public class tp2TrainingActivity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tp2_id_activity")
    private int tp2IdActivity;

    @Column(name = "tp2_name", length = 200, nullable = false)
    private String tp2Name;

    @Column(name = "tp2_quantity", nullable = false)
    private int tp2Quantity;

    @Column(name = "tp2_date", nullable = false)
    private LocalDate tp2Date;

    @Column(name = "tp2_price", precision = 18, scale = 2, nullable = false)
    private BigDecimal tp2Price;

    @ManyToOne
    @JoinColumn(name = "tp2_training_id", nullable = false)
    private tp2TrainingProgram tp2TrainingProgram;

    @ManyToOne
    @JoinColumn(name = "tp2_category_id", nullable = false)
    private tp2TrainingCategory tp2TrainingCategory;

    public tp2TrainingActivity() {
    }

    public tp2TrainingActivity(int tp2IdActivity, String tp2Name, int tp2Quantity, LocalDate tp2Date,
                                BigDecimal tp2Price, tp2TrainingProgram tp2TrainingProgram,
                                tp2TrainingCategory tp2TrainingCategory) {
        this.tp2IdActivity = tp2IdActivity;
        this.tp2Name = tp2Name;
        this.tp2Quantity = tp2Quantity;
        this.tp2Date = tp2Date;
        this.tp2Price = tp2Price;
        this.tp2TrainingProgram = tp2TrainingProgram;
        this.tp2TrainingCategory = tp2TrainingCategory;
    }

    public int getTp2IdActivity() {
        return tp2IdActivity;
    }

    public void setTp2IdActivity(int tp2IdActivity) {
        this.tp2IdActivity = tp2IdActivity;
    }

    public String getTp2Name() {
        return tp2Name;
    }

    public void setTp2Name(String tp2Name) {
        this.tp2Name = tp2Name;
    }

    public int getTp2Quantity() {
        return tp2Quantity;
    }

    public void setTp2Quantity(int tp2Quantity) {
        this.tp2Quantity = tp2Quantity;
    }

    public LocalDate getTp2Date() {
        return tp2Date;
    }

    public void setTp2Date(LocalDate tp2Date) {
        this.tp2Date = tp2Date;
    }

    public BigDecimal getTp2Price() {
        return tp2Price;
    }

    public void setTp2Price(BigDecimal tp2Price) {
        this.tp2Price = tp2Price;
    }

    public tp2TrainingProgram getTp2TrainingProgram() {
        return tp2TrainingProgram;
    }

    public void setTp2TrainingProgram(tp2TrainingProgram tp2TrainingProgram) {
        this.tp2TrainingProgram = tp2TrainingProgram;
    }

    public tp2TrainingCategory getTp2TrainingCategory() {
        return tp2TrainingCategory;
    }

    public void setTp2TrainingCategory(tp2TrainingCategory tp2TrainingCategory) {
        this.tp2TrainingCategory = tp2TrainingCategory;
    }
}
