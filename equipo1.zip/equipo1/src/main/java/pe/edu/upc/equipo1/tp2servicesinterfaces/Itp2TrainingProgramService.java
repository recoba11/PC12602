package pe.edu.upc.equipo1.tp2servicesinterfaces;

import pe.edu.upc.equipo1.tp2dtos.tp2TrainingQuantityDTO;
import pe.edu.upc.equipo1.tp2entities.tp2TrainingProgram;

import java.util.List;
import java.util.Optional;

public interface Itp2TrainingProgramService {

    Optional<tp2TrainingProgram> listId(int id);

    tp2TrainingProgram update(int id, tp2TrainingProgram program);

    List<tp2TrainingQuantityDTO> quantitiesByProgramAndCategory();
}
