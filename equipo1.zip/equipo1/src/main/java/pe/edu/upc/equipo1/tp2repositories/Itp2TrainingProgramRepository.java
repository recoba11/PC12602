package pe.edu.upc.equipo1.tp2repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pe.edu.upc.equipo1.tp2entities.tp2TrainingProgram;

@Repository
public interface Itp2TrainingProgramRepository extends JpaRepository<tp2TrainingProgram, Integer> {
}
