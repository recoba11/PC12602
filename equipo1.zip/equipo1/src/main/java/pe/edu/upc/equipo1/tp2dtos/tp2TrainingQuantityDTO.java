package pe.edu.upc.equipo1.tp2dtos;

public interface tp2TrainingQuantityDTO {
    String getPrograma();
    String getCategoria();
    Long getCantidadTotal();
}
