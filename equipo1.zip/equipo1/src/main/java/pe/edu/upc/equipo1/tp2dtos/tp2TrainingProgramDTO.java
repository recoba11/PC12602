package pe.edu.upc.equipo1.tp2dtos;

import java.time.LocalDate;

public class tp2TrainingProgramDTO {

    private int tp2IdProgram;
    private String tp2Denomination;
    private String tp2Description;
    private String tp2Modality;
    private LocalDate tp2DateProgram;

    public int getTp2IdProgram() {
        return tp2IdProgram;
    }

    public void setTp2IdProgram(int tp2IdProgram) {
        this.tp2IdProgram = tp2IdProgram;
    }

    public String getTp2Denomination() {
        return tp2Denomination;
    }

    public void setTp2Denomination(String tp2Denomination) {
        this.tp2Denomination = tp2Denomination;
    }

    public String getTp2Description() {
        return tp2Description;
    }

    public void setTp2Description(String tp2Description) {
        this.tp2Description = tp2Description;
    }

    public String getTp2Modality() {
        return tp2Modality;
    }

    public void setTp2Modality(String tp2Modality) {
        this.tp2Modality = tp2Modality;
    }

    public LocalDate getTp2DateProgram() {
        return tp2DateProgram;
    }

    public void setTp2DateProgram(LocalDate tp2DateProgram) {
        this.tp2DateProgram = tp2DateProgram;
    }
}
