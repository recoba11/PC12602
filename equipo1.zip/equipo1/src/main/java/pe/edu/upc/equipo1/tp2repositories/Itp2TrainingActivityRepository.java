package pe.edu.upc.equipo1.tp2repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import pe.edu.upc.equipo1.tp2dtos.tp2TrainingQuantityDTO;
import pe.edu.upc.equipo1.tp2entities.tp2TrainingActivity;

import java.util.List;

@Repository
public interface Itp2TrainingActivityRepository extends JpaRepository<tp2TrainingActivity, Integer> {

    @Query(value = "SELECT tprog.tp2_denomination as \"programa\", tcat.tp2_name as \"categoria\", " +
            "COUNT(tact.tp2_id_activity) as \"cantidadTotal\" " +
            "FROM training_activity tact " +
            "INNER JOIN training_program tprog ON tact.tp2_training_id = tprog.tp2_id_program " +
            "INNER JOIN training_category tcat ON tact.tp2_category_id = tcat.tp2_id_category " +
            "GROUP BY tprog.tp2_denomination, tcat.tp2_name", nativeQuery = true)
    List<tp2TrainingQuantityDTO> tp2_findQuantitiesByProgramAndCategory();
}
