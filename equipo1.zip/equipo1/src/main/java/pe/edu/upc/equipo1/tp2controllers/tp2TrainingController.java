package pe.edu.upc.equipo1.tp2controllers;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import pe.edu.upc.equipo1.tp2dtos.tp2TrainingProgramDTO;
import pe.edu.upc.equipo1.tp2dtos.tp2TrainingQuantityDTO;
import pe.edu.upc.equipo1.tp2entities.tp2TrainingProgram;
import pe.edu.upc.equipo1.tp2servicesinterfaces.Itp2TrainingProgramService;

@Tag(name = "Trainings", description = "Endpoints para gestionar programas de capacitacion")
@RestController
@RequestMapping("/api/trainings")
public class tp2TrainingController {

    @Autowired
    private Itp2TrainingProgramService e2_trainingService;

    @Operation(summary = "HUB01 - Actualizar programa de capacitacion")
    @PutMapping("/updates/{id}")
    public ResponseEntity<?> updates(@PathVariable int id, @RequestBody tp2TrainingProgramDTO dto) {
        if (dto.getTp2Denomination() == null || dto.getTp2Denomination().isBlank() ||
                dto.getTp2Modality() == null || dto.getTp2Modality().isBlank() ||
                dto.getTp2DateProgram() == null) {
            return ResponseEntity.badRequest()
                    .body("La denominacion, la modalidad y la fecha del programa son obligatorias");
        }

        ModelMapper m = new ModelMapper();
        tp2TrainingProgram e2_programaMapeado = m.map(dto, tp2TrainingProgram.class);
        tp2TrainingProgram e2_programaActualizado = e2_trainingService.update(id, e2_programaMapeado);

        if (e2_programaActualizado == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un programa de capacitacion con el id: " + id);
        }

        tp2TrainingProgramDTO e2_responseDTO = m.map(e2_programaActualizado, tp2TrainingProgramDTO.class);
        return ResponseEntity.ok(e2_responseDTO);
    }

    @Operation(summary = "HUB02 - Cantidad total de actividades por categoria y programa de capacitacion")
    @GetMapping("/quantities")
    public ResponseEntity<?> quantities() {
        List<tp2TrainingQuantityDTO> e2_lista = e2_trainingService.quantitiesByProgramAndCategory();

        if (e2_lista.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existen actividades de capacitacion registradas");
        }

        return ResponseEntity.ok(e2_lista);
    }
}
