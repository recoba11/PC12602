package pe.edu.upc.api17732.hsgcdtos;

import java.time.LocalDate;

public class hsgcImpactoAmbientalDTO {

    private int hsgcIdImpactoAmbiental;
    private String hsgcTipoImpacto;
    private String hsgcDescription;
    private String hsgcNivel;
    private LocalDate hsgcFechaEvaluacion;
    private String hsgcAreaAfectada;

    public int getHsgcIdImpactoAmbiental() {
        return hsgcIdImpactoAmbiental;
    }

    public void setHsgcIdImpactoAmbiental(int hsgcIdImpactoAmbiental) {
        this.hsgcIdImpactoAmbiental = hsgcIdImpactoAmbiental;
    }

    public String getHsgcTipoImpacto() {
        return hsgcTipoImpacto;
    }

    public void setHsgcTipoImpacto(String hsgcTipoImpacto) {
        this.hsgcTipoImpacto = hsgcTipoImpacto;
    }

    public String getHsgcDescription() {
        return hsgcDescription;
    }

    public void setHsgcDescription(String hsgcDescription) {
        this.hsgcDescription = hsgcDescription;
    }

    public String getHsgcNivel() {
        return hsgcNivel;
    }

    public void setHsgcNivel(String hsgcNivel) {
        this.hsgcNivel = hsgcNivel;
    }

    public LocalDate getHsgcFechaEvaluacion() {
        return hsgcFechaEvaluacion;
    }

    public void setHsgcFechaEvaluacion(LocalDate hsgcFechaEvaluacion) {
        this.hsgcFechaEvaluacion = hsgcFechaEvaluacion;
    }

    public String getHsgcAreaAfectada() {
        return hsgcAreaAfectada;
    }

    public void setHsgcAreaAfectada(String hsgcAreaAfectada) {
        this.hsgcAreaAfectada = hsgcAreaAfectada;
    }
}
