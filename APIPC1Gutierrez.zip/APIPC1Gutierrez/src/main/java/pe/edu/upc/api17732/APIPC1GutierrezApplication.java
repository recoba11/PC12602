package pe.edu.upc.api17732;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecobaFunciyuValenzuelaHuaynilloApplication {

    public static void main(String[] args) {
        SpringApplication.run(RecobaFunciyuValenzuelaHuaynilloApplication.class, args);
    }

}
