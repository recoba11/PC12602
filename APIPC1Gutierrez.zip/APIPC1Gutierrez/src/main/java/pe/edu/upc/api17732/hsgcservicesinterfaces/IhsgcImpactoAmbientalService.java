package pe.edu.upc.api17732.hsgcservicesinterfaces;

import pe.edu.upc.api17732.hsgcdtos.hsgcImpactoCountDTO;
import pe.edu.upc.api17732.hsgcentities.hsgcImpactoAmbiental;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface IhsgcImpactoAmbientalService {

    hsgcImpactoAmbiental insert(hsgcImpactoAmbiental ia);

    Optional<hsgcImpactoAmbiental> listId(int id);

    List<hsgcImpactoCountDTO> countByTipoImpacto();

    List<hsgcImpactoAmbiental> findByFechaBetween(LocalDate startDate, LocalDate endDate);

    List<hsgcImpactoAmbiental> findAllOrderedByNivel();
}
