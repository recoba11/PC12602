package pe.edu.upc.api17732.hsgcservicesimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.api17732.hsgcdtos.hsgcImpactoCountDTO;
import pe.edu.upc.api17732.hsgcentities.hsgcImpactoAmbiental;
import pe.edu.upc.api17732.hsgcrepositories.IhsgcImpactoAmbientalRepository;
import pe.edu.upc.api17732.hsgcservicesinterfaces.IhsgcImpactoAmbientalService;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class hsgcImpactoAmbientalServiceImplement implements IhsgcImpactoAmbientalService {

    @Autowired
    private IhsgcImpactoAmbientalRepository iaR;

    @Override
    public hsgcImpactoAmbiental insert(hsgcImpactoAmbiental ia) {
        return iaR.save(ia);
    }

    @Override
    public Optional<hsgcImpactoAmbiental> listId(int id) {
        return iaR.findById(id);
    }

    @Override
    public List<hsgcImpactoCountDTO> countByTipoImpacto() {
        return iaR.countByTipoImpacto();
    }

    @Override
    public List<hsgcImpactoAmbiental> findByFechaBetween(LocalDate startDate, LocalDate endDate) {
        return iaR.findByHsgcFechaEvaluacionBetween(startDate, endDate);
    }

    @Override
    public List<hsgcImpactoAmbiental> findAllOrderedByNivel() {
        return iaR.findAllByOrderByHsgcNivelAsc();
    }
}
