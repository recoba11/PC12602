package pe.edu.upc.api17732.hsgcdtos;

public interface hsgcImpactoCountDTO {
    String getHsgcTipoImpacto();
    Long getHsgcCantidad();
}
