package pe.edu.upc.api17732.hsgcentities;

import jakarta.persistence.*;

@Entity
@Table(name = "recomendacion_ambiental")
public class hsgcRecomendacionAmbiental {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hsgc_id_recomendacion")
    private int hsgcIdRecomendacion;

    @Column(name = "hsgc_titulo", length = 100, nullable = false)
    private String hsgcTitulo;

    @Column(name = "hsgc_descripcion", length = 300, nullable = false)
    private String hsgcDescripcion;

    @Column(name = "hsgc_prioridad", length = 20, nullable = false)
    private String hsgcPrioridad;

    @Column(name = "hsgc_estado", length = 20, nullable = false)
    private String hsgcEstado;

    @ManyToOne
    @JoinColumn(name = "hsgc_id_impacto")
    private hsgcImpactoAmbiental hsgcImpactoAmbiental;

    public hsgcRecomendacionAmbiental() {
    }

    public hsgcRecomendacionAmbiental(int hsgcIdRecomendacion, String hsgcTitulo, String hsgcDescripcion,
                                       String hsgcPrioridad, String hsgcEstado, hsgcImpactoAmbiental hsgcImpactoAmbiental) {
        this.hsgcIdRecomendacion = hsgcIdRecomendacion;
        this.hsgcTitulo = hsgcTitulo;
        this.hsgcDescripcion = hsgcDescripcion;
        this.hsgcPrioridad = hsgcPrioridad;
        this.hsgcEstado = hsgcEstado;
        this.hsgcImpactoAmbiental = hsgcImpactoAmbiental;
    }

    public int getHsgcIdRecomendacion() {
        return hsgcIdRecomendacion;
    }

    public void setHsgcIdRecomendacion(int hsgcIdRecomendacion) {
        this.hsgcIdRecomendacion = hsgcIdRecomendacion;
    }

    public String getHsgcTitulo() {
        return hsgcTitulo;
    }

    public void setHsgcTitulo(String hsgcTitulo) {
        this.hsgcTitulo = hsgcTitulo;
    }

    public String getHsgcDescripcion() {
        return hsgcDescripcion;
    }

    public void setHsgcDescripcion(String hsgcDescripcion) {
        this.hsgcDescripcion = hsgcDescripcion;
    }

    public String getHsgcPrioridad() {
        return hsgcPrioridad;
    }

    public void setHsgcPrioridad(String hsgcPrioridad) {
        this.hsgcPrioridad = hsgcPrioridad;
    }

    public String getHsgcEstado() {
        return hsgcEstado;
    }

    public void setHsgcEstado(String hsgcEstado) {
        this.hsgcEstado = hsgcEstado;
    }

    public hsgcImpactoAmbiental getHsgcImpactoAmbiental() {
        return hsgcImpactoAmbiental;
    }

    public void setHsgcImpactoAmbiental(hsgcImpactoAmbiental hsgcImpactoAmbiental) {
        this.hsgcImpactoAmbiental = hsgcImpactoAmbiental;
    }
}
