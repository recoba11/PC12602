package pe.edu.upc.api17732.hsgcdtos;

import java.time.LocalDate;

public class hsgcImpactoPeriodoDTO {

    private String hsgcTipoImpacto;
    private String hsgcNivel;
    private String hsgcAreaAfectada;
    private LocalDate hsgcFechaEvaluacion;

    public hsgcImpactoPeriodoDTO() {
    }

    public hsgcImpactoPeriodoDTO(String hsgcTipoImpacto, String hsgcNivel, String hsgcAreaAfectada, LocalDate hsgcFechaEvaluacion) {
        this.hsgcTipoImpacto = hsgcTipoImpacto;
        this.hsgcNivel = hsgcNivel;
        this.hsgcAreaAfectada = hsgcAreaAfectada;
        this.hsgcFechaEvaluacion = hsgcFechaEvaluacion;
    }

    public String getHsgcTipoImpacto() {
        return hsgcTipoImpacto;
    }

    public void setHsgcTipoImpacto(String hsgcTipoImpacto) {
        this.hsgcTipoImpacto = hsgcTipoImpacto;
    }

    public String getHsgcNivel() {
        return hsgcNivel;
    }

    public void setHsgcNivel(String hsgcNivel) {
        this.hsgcNivel = hsgcNivel;
    }

    public String getHsgcAreaAfectada() {
        return hsgcAreaAfectada;
    }

    public void setHsgcAreaAfectada(String hsgcAreaAfectada) {
        this.hsgcAreaAfectada = hsgcAreaAfectada;
    }

    public LocalDate getHsgcFechaEvaluacion() {
        return hsgcFechaEvaluacion;
    }

    public void setHsgcFechaEvaluacion(LocalDate hsgcFechaEvaluacion) {
        this.hsgcFechaEvaluacion = hsgcFechaEvaluacion;
    }
}
