package pe.edu.upc.api17732.hsgcrepositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import pe.edu.upc.api17732.hsgcdtos.hsgcImpactoCountDTO;
import pe.edu.upc.api17732.hsgcentities.hsgcImpactoAmbiental;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface IhsgcImpactoAmbientalRepository extends JpaRepository<hsgcImpactoAmbiental, Integer> {

    @Query(value = "SELECT hsgc_tipo_impacto as \"hsgcTipoImpacto\", COUNT(*) as \"hsgcCantidad\" " +
            "FROM impacto_ambiental GROUP BY hsgc_tipo_impacto", nativeQuery = true)
    List<hsgcImpactoCountDTO> countByTipoImpacto();

    List<hsgcImpactoAmbiental> findByHsgcFechaEvaluacionBetween(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

    List<hsgcImpactoAmbiental> findAllByOrderByHsgcNivelAsc();
}
