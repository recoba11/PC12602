package pe.edu.upc.api17732.hsgccontrollers;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import pe.edu.upc.api17732.hsgcdtos.hsgcImpactoAmbientalDTO;
import pe.edu.upc.api17732.hsgcdtos.hsgcImpactoCountDTO;
import pe.edu.upc.api17732.hsgcdtos.hsgcImpactoPeriodoDTO;
import pe.edu.upc.api17732.hsgcentities.hsgcImpactoAmbiental;
import pe.edu.upc.api17732.hsgcservicesinterfaces.IhsgcImpactoAmbientalService;

@Tag(name = "ImpactoAmbiental", description = "Endpoints para gestionar impactos ambientales")
@RestController
@RequestMapping("/virtual-pc1")
public class hsgcImpactoAmbientalController {

    @Autowired
    private IhsgcImpactoAmbientalService hsgs20S;

    @Operation(summary = "HUB01 - Registrar impacto ambiental")
    @PostMapping("/recoba-funciyu-valenzuela-huaynillo/nuevo")
    public ResponseEntity<?> registrar(@RequestBody hsgcImpactoAmbientalDTO dto) {
        if (dto.getHsgcTipoImpacto() == null || dto.getHsgcTipoImpacto().isBlank() ||
                dto.getHsgcDescription() == null || dto.getHsgcDescription().isBlank() ||
                dto.getHsgcNivel() == null || dto.getHsgcNivel().isBlank() ||
                dto.getHsgcFechaEvaluacion() == null ||
                dto.getHsgcAreaAfectada() == null || dto.getHsgcAreaAfectada().isBlank()) {
            return ResponseEntity.badRequest()
                    .body("Todos los campos son obligatorios, no se permiten campos en blanco");
        }

        ModelMapper m = new ModelMapper();
        hsgcImpactoAmbiental ia = m.map(dto, hsgcImpactoAmbiental.class);
        hsgcImpactoAmbiental guardado = hsgs20S.insert(ia);
        hsgcImpactoAmbientalDTO responseDTO = m.map(guardado, hsgcImpactoAmbientalDTO.class);
        return ResponseEntity.status(HttpStatus.CREATED).body(responseDTO);
    }

    @Operation(summary = "HUB02 - Listar impacto ambiental por ID")
    @GetMapping("/recoba-funciyu-valenzuela-huaynillo/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable int id) {
        ModelMapper m = new ModelMapper();
        Optional<hsgcImpactoAmbiental> encontrado = hsgs20S.listId(id);

        if (encontrado.isPresent()) {
            hsgcImpactoAmbientalDTO dto = m.map(encontrado.get(), hsgcImpactoAmbientalDTO.class);
            return ResponseEntity.ok(dto);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existe un impacto ambiental con el id: " + id);
        }
    }

    @Operation(summary = "HUB03 - Cantidad de impactos ambientales por tipo")
    @GetMapping("/recoba-funciyu-valenzuela-huaynillo/tipo")
    public ResponseEntity<?> cantidadPorTipo() {
        List<hsgcImpactoCountDTO> lista = hsgs20S.countByTipoImpacto();

        if (lista.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No existen registros de impactos ambientales");
        }

        return ResponseEntity.ok(lista);
    }

    @Operation(summary = "HUB04 - Impactos ambientales entre un periodo de tiempo")
    @GetMapping("/recoba-funciyu-valenzuela-huaynillo/periodo")
    public ResponseEntity<?> buscarPorPeriodo(
            @RequestParam String startDate,
            @RequestParam String endDate) {

        LocalDate inicio = LocalDate.parse(startDate);
        LocalDate fin = LocalDate.parse(endDate);

        if (inicio.isAfter(fin)) {
            return ResponseEntity.badRequest()
                    .body("La fecha de inicio no puede ser posterior a la fecha fin");
        }

        List<hsgcImpactoAmbiental> lista = hsgs20S.findByFechaBetween(inicio, fin);

        if (lista.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No hay registros de impactos ambientales en el periodo indicado");
        }

        List<hsgcImpactoPeriodoDTO> resultado = lista.stream().map(ia -> {
            hsgcImpactoPeriodoDTO dto = new hsgcImpactoPeriodoDTO();
            dto.setHsgcTipoImpacto(ia.getHsgcTipoImpacto());
            dto.setHsgcNivel(ia.getHsgcNivel());
            dto.setHsgcAreaAfectada(ia.getHsgcAreaAfectada());
            dto.setHsgcFechaEvaluacion(ia.getHsgcFechaEvaluacion());
            return dto;
        }).collect(Collectors.toList());

        return ResponseEntity.ok(resultado);
    }

    @Operation(summary = "HUB05 - Impactos ambientales ordenados ascendentemente por nivel")
    @GetMapping("/recoba-funciyu-valenzuela-huaynillo/nivel")
    public ResponseEntity<?> listarOrdenadosPorNivel() {
        ModelMapper m = new ModelMapper();

        List<hsgcImpactoAmbientalDTO> lista = hsgs20S.findAllOrderedByNivel()
                .stream()
                .map(ia -> m.map(ia, hsgcImpactoAmbientalDTO.class))
                .collect(Collectors.toList());

        if (lista.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("No hay registros de impactos ambientales");
        }

        return ResponseEntity.ok(lista);
    }
}
