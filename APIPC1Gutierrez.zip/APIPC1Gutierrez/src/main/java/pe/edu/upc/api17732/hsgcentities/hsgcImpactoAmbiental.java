package pe.edu.upc.api17732.hsgcentities;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "impacto_ambiental")
public class hsgcImpactoAmbiental {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hsgc_id_impacto_ambiental")
    private int hsgcIdImpactoAmbiental;

    @Column(name = "hsgc_tipo_impacto", length = 80, nullable = false)
    private String hsgcTipoImpacto;

    @Column(name = "hsgc_description", length = 250, nullable = false)
    private String hsgcDescription;

    @Column(name = "hsgc_nivel", length = 20, nullable = false)
    private String hsgcNivel;

    @Column(name = "hsgc_fecha_evaluacion", nullable = false)
    private LocalDate hsgcFechaEvaluacion;

    @Column(name = "hsgc_area_afectada", length = 100, nullable = false)
    private String hsgcAreaAfectada;

    public hsgcImpactoAmbiental() {
    }

    public hsgcImpactoAmbiental(int hsgcIdImpactoAmbiental, String hsgcTipoImpacto, String hsgcDescription,
                                 String hsgcNivel, LocalDate hsgcFechaEvaluacion, String hsgcAreaAfectada) {
        this.hsgcIdImpactoAmbiental = hsgcIdImpactoAmbiental;
        this.hsgcTipoImpacto = hsgcTipoImpacto;
        this.hsgcDescription = hsgcDescription;
        this.hsgcNivel = hsgcNivel;
        this.hsgcFechaEvaluacion = hsgcFechaEvaluacion;
        this.hsgcAreaAfectada = hsgcAreaAfectada;
    }

    public int getHsgcIdImpactoAmbiental() {
        return hsgcIdImpactoAmbiental;
    }

    public void setHsgcIdImpactoAmbiental(int hsgcIdImpactoAmbiental) {
        this.hsgcIdImpactoAmbiental = hsgcIdImpactoAmbiental;
    }

    public String getHsgcTipoImpacto() {
        return hsgcTipoImpacto;
    }

    public void setHsgcTipoImpacto(String hsgcTipoImpacto) {
        this.hsgcTipoImpacto = hsgcTipoImpacto;
    }

    public String getHsgcDescription() {
        return hsgcDescription;
    }

    public void setHsgcDescription(String hsgcDescription) {
        this.hsgcDescription = hsgcDescription;
    }

    public String getHsgcNivel() {
        return hsgcNivel;
    }

    public void setHsgcNivel(String hsgcNivel) {
        this.hsgcNivel = hsgcNivel;
    }

    public LocalDate getHsgcFechaEvaluacion() {
        return hsgcFechaEvaluacion;
    }

    public void setHsgcFechaEvaluacion(LocalDate hsgcFechaEvaluacion) {
        this.hsgcFechaEvaluacion = hsgcFechaEvaluacion;
    }

    public String getHsgcAreaAfectada() {
        return hsgcAreaAfectada;
    }

    public void setHsgcAreaAfectada(String hsgcAreaAfectada) {
        this.hsgcAreaAfectada = hsgcAreaAfectada;
    }
}
